#include <window.h>

uint8_t windowPosition = 0;
uint8_t windowMovement = INITIALIZE;
uint8_t antiPinchFlag = FALSE;

void PORTC_IRQHandler(void)
{
  WINDOW_Interrupt_State_Manager(&windowMovement);
}

int main(void)
{
  while(1)
  {
    switch(windowMovement)
    {
      case INITIALIZE:
      {
        windowMovement = DO_NOTHING;
        WINDOW_State_Initialize();

      } break;
      case WINDOW_MOVE_UP:
      {
        windowMovement = DO_NOTHING;
        WINDOW_State_Move_Up(&windowPosition, &windowMovement, &antiPinchFlag);
      } break;
      case WINDOW_MOVE_DOWN:
      {
        windowMovement = DO_NOTHING;
        WINDOW_State_Move_Down(&windowPosition, &windowMovement);
      } break;
      case WINDOW_ANTI_PINCH:
      {
        WINDOW_State_Anti_Pinch(&windowPosition, &windowMovement, &antiPinchFlag);
      } break;
      case WAIT_TIMER:
      {
        TIMER_Delay_Milliseconds(TIME_ANTI_PINCH_DELAY);
        windowMovement = DO_NOTHING;
      } break;
      default:
        break;
    }
  }
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  //for(;;) {
    //if(exit_code != 0) {
     // break;
    //}
  //}
  return 0;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/
