/*
 * window.h
 *
 *  Created on: 25/10/2018
 *      Author: Jorge Roberto
 */

#ifndef WINDOW_H_
#define WINDOW_H_

#include "Cpu.h"

#ifndef STDINT_H_
#include <stdint.h>
#endif

#ifndef DEFINITIONS_H_
#include "definitions.h"
#endif

#ifndef CLOCK_H_
#include "clock.h"
#endif

#ifndef GPIO_H_
#include "gpio.h"
#endif

#ifndef TIMER_H_
#include "timer.h"
#endif

#ifndef LPSPI1_H_
#include "LPSPI1.h"
#endif

void WINDOW_Interrupt_State_Manager(uint8_t *ptrWindowMovement);

void WINDOW_State_Initialize(void);
void WINDOW_State_Move_Up(uint8_t *ptrWindowPosition, uint8_t *ptrWindowMovement, uint8_t *ptrAntiPinchFlag);
void WINDOW_State_Move_Down(uint8_t *ptrWindowPosition, uint8_t *ptrWindowMovement);
void WINDOW_State_Anti_Pinch(uint8_t *ptrWindowPosition, uint8_t *ptrWindowMovement, uint8_t *ptrAntiPinchFlag);

void WINDOW_Move_Up(uint8_t *ptrWindowPosition);
void WINDOW_Move_Down(uint8_t *ptrWindowPosition);

uint8_t WINDOW_Get_Port_Char(uint8_t *ptrWindowPosition);
uint8_t WINDOW_Get_Port_Pin(uint8_t *ptrWindowPosition);

#endif /* WINDOW_H_ */
