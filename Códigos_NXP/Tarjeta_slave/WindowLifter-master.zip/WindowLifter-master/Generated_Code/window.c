/*
 * window.c
*/
#include "window.h"

void WINDOW_Interrupt_State_Manager(uint8_t *ptrWindowMovement)
{
	uint8_t In_Interrupt = 0;
	uint8_t Time_Duration_Criterio = 0;

	In_Interrupt = GPIO_Read_Input_Interrupt(PRT_C, PIN_12);
  if(In_Interrupt == TRUE)
  {
	  Time_Duration_Criterio = TIMER_Button_Pressed_With_Duration_Criteria(PRT_C, PIN_12, TIME_MIN_RESOLUTION);
    if(Time_Duration_Criterio == TRUE)
    {
      *ptrWindowMovement = WINDOW_MOVE_UP;
    }
  }
  else if (GPIO_Read_Input_Interrupt(PRT_C, PIN_13) == TRUE)
  {
    if(TIMER_Button_Pressed_With_Duration_Criteria(PRT_C, PIN_13, TIME_MIN_RESOLUTION) == TRUE)
    {
      *ptrWindowMovement = WINDOW_MOVE_DOWN;
    }
  }
  else
  {
    if(TIMER_Button_Pressed_With_Duration_Criteria(PRT_C, PIN_17, TIME_MIN_RESOLUTION) == TRUE)
    {
      *ptrWindowMovement = WINDOW_ANTI_PINCH;
    }
  }
  GPIO_Clear_Interrupt(PRT_C, PIN_12);
  GPIO_Clear_Interrupt(PRT_C, PIN_13);
  GPIO_Clear_Interrupt(PRT_C, PIN_17);
}

void WINDOW_State_Initialize()
{
  CLOCK_SOSC_Init_8MHz();
  CLOCK_SPLL_Init_160MHz();
  CLOCK_Setup_80MHz();
  CLOCK_Disable_Watchdog();
  PORT_v_InitializeSPI_Pins ();
  LPSPI1_v_Initialization();


  GPIO_Clock_Set_Up(PRT_A);
  GPIO_Clock_Set_Up(PRT_C);
  GPIO_Clock_Set_Up(PRT_D);
  GPIO_Clock_Set_Up(PRT_E);

  GPIO_Init_As_Input(PRT_C,  PIN_12);
  GPIO_Init_As_Input(PRT_C,  PIN_13);
  GPIO_Init_As_Input(PRT_C,  PIN_17);

  GPIO_Enable_Port_Interrupt(PRT_C);


  GPIO_Init_As_Output(PRT_A,  PIN_11);
  GPIO_Init_As_Output(PRT_A,  PIN_17);
  GPIO_Init_As_Output(PRT_D,   PIN_0);//Se cambia por led rojo
  GPIO_Init_As_Output(PRT_D,   PIN_3);
  GPIO_Init_As_Output(PRT_D,   PIN_5);
  GPIO_Init_As_Output(PRT_D,  PIN_10);
  GPIO_Init_As_Output(PRT_D,  PIN_11);
  GPIO_Init_As_Output(PRT_D,  PIN_12);
  GPIO_Init_As_Output(PRT_D,  PIN_16);
  GPIO_Init_As_Output(PRT_E,   PIN_3);
  GPIO_Init_As_Output(PRT_E,   PIN_4);
  GPIO_Init_As_Output(PRT_E,   PIN_5);

  GPIO_Set_Off_Output(PRT_A,  PIN_11);
  GPIO_Set_Off_Output(PRT_A,  PIN_17);
  GPIO_Set_On_Output(PRT_D,    PIN_0);
  GPIO_Set_On_Output(PRT_D,   PIN_16);
  GPIO_Set_Off_Output(PRT_D,   PIN_3);
  GPIO_Set_Off_Output(PRT_D,   PIN_5);
  GPIO_Set_Off_Output(PRT_D,  PIN_10);
  GPIO_Set_Off_Output(PRT_D,  PIN_11);
  GPIO_Set_Off_Output(PRT_D,  PIN_12);
  GPIO_Set_Off_Output(PRT_E,   PIN_3);
  GPIO_Set_Off_Output(PRT_E,   PIN_4);
  GPIO_Set_Off_Output(PRT_E,   PIN_5);
}

void WINDOW_State_Move_Up(uint8_t *ptrWindowPosition, uint8_t *ptrWindowMovement, uint8_t *ptrAntiPinchFlag)
{
	uint16_t LPSPI1_16bits_read;
  uint8_t pressedButtonCyclesCounter = MIN_CYCLES_TO_CONSIDER_VALID_PRESS;
  if(*ptrWindowPosition < MAX_POSITION)
  {
    //GPIO_Set_Off_Output(PRT_D, PIN_0); /*turns ON Blue LED*/

    LPSPI1_v_Send_8_bits_Data(0xf1);

    LPSPI1_16bits_read = LPSPI1_v_Receive_16bits_Data();

    WINDOW_Move_Up(ptrWindowPosition);
  }
  while((GPIO_Read_Input(PRT_C, PIN_12) == TRUE) && (*ptrWindowMovement == DO_NOTHING) && (pressedButtonCyclesCounter < CYCLES_TO_CONSIDER_MANUAL_OR_AUTO))
  {
    if(pressedButtonCyclesCounter == (CYCLES_FOR_ONE_LED_TRANSITION + MIN_CYCLES_TO_CONSIDER_VALID_PRESS))
    {
      WINDOW_Move_Up(ptrWindowPosition);
    }
    TIMER_Delay_Milliseconds(TIME_MIN_RESOLUTION);
    ++pressedButtonCyclesCounter;
  }
  if(pressedButtonCyclesCounter < (CYCLES_FOR_ONE_LED_TRANSITION + MIN_CYCLES_TO_CONSIDER_VALID_PRESS))
  {
    TIMER_Delay_Milliseconds(((CYCLES_FOR_ONE_LED_TRANSITION + MIN_CYCLES_TO_CONSIDER_VALID_PRESS)-pressedButtonCyclesCounter)*TIME_MIN_RESOLUTION);
  }
  else
  {
    TIMER_Delay_Milliseconds(((CYCLES_FOR_TWO_LED_TRANSITION + MIN_CYCLES_TO_CONSIDER_VALID_PRESS)-pressedButtonCyclesCounter)*TIME_MIN_RESOLUTION);
  }
  if(pressedButtonCyclesCounter < CYCLES_TO_CONSIDER_MANUAL_OR_AUTO)
  {
    while((*ptrWindowPosition < MAX_POSITION) && (*ptrWindowMovement == DO_NOTHING))
    {
      WINDOW_Move_Up(ptrWindowPosition);
      TIMER_Delay_Milliseconds(TIME_LED_TRANSITION);
    }
  }
  else
  {
    while((GPIO_Read_Input(PRT_C, PIN_12) == TRUE) && (*ptrWindowPosition < MAX_POSITION) && (*ptrWindowMovement == DO_NOTHING))
    {
      WINDOW_Move_Up(ptrWindowPosition);
      TIMER_Delay_Milliseconds(TIME_LED_TRANSITION);
    }
  }
  GPIO_Set_On_Output(PRT_D, PIN_0);
  if(*ptrWindowMovement == WINDOW_ANTI_PINCH)
  {
    *ptrAntiPinchFlag = TRUE;
  }
}

void WINDOW_State_Move_Down(uint8_t *ptrWindowPosition, uint8_t *ptrWindowMovement)
{
  uint16_t LPSPI1_16bits_read;
  uint8_t pressedButtonCyclesCounter = MIN_CYCLES_TO_CONSIDER_VALID_PRESS;
  if(*ptrWindowPosition > MIN_POSITION)
  {
    //GPIO_Set_Off_Output(PRT_D, PIN_16); /*turns ON Green LED*/
    WINDOW_Move_Down(ptrWindowPosition);

    LPSPI1_v_Send_8_bits_Data(0xf2);
    LPSPI1_16bits_read = LPSPI1_v_Receive_16bits_Data();
  }
  while((GPIO_Read_Input(PRT_C, PIN_13) == TRUE) && (*ptrWindowMovement != WINDOW_MOVE_UP) && (*ptrWindowMovement != WINDOW_MOVE_DOWN) && (pressedButtonCyclesCounter < CYCLES_TO_CONSIDER_MANUAL_OR_AUTO))
  {
    if(pressedButtonCyclesCounter == (CYCLES_FOR_ONE_LED_TRANSITION + MIN_CYCLES_TO_CONSIDER_VALID_PRESS))
    {
      WINDOW_Move_Down(ptrWindowPosition);
    }
    TIMER_Delay_Milliseconds(TIME_MIN_RESOLUTION);
    ++pressedButtonCyclesCounter;
  }
  if(pressedButtonCyclesCounter < (CYCLES_FOR_ONE_LED_TRANSITION + MIN_CYCLES_TO_CONSIDER_VALID_PRESS))
  {
    TIMER_Delay_Milliseconds(((CYCLES_FOR_ONE_LED_TRANSITION + MIN_CYCLES_TO_CONSIDER_VALID_PRESS)-pressedButtonCyclesCounter)*TIME_MIN_RESOLUTION);
  }
  else
  {
    TIMER_Delay_Milliseconds(((CYCLES_FOR_TWO_LED_TRANSITION + MIN_CYCLES_TO_CONSIDER_VALID_PRESS)-pressedButtonCyclesCounter)*TIME_MIN_RESOLUTION);
  }
  if(pressedButtonCyclesCounter < CYCLES_TO_CONSIDER_MANUAL_OR_AUTO)
  {
    while((*ptrWindowPosition > MIN_POSITION) && (*ptrWindowMovement != WINDOW_MOVE_UP) && (*ptrWindowMovement != WINDOW_MOVE_DOWN))
    {
      WINDOW_Move_Down(ptrWindowPosition);
      TIMER_Delay_Milliseconds(TIME_LED_TRANSITION);
    }
  }
  else
  {
    while((GPIO_Read_Input(PRT_C, PIN_13) == TRUE) && (*ptrWindowPosition > MIN_POSITION) && (*ptrWindowMovement != WINDOW_MOVE_UP) && (*ptrWindowMovement != WINDOW_MOVE_DOWN))
    {
      WINDOW_Move_Down(ptrWindowPosition);
      TIMER_Delay_Milliseconds(TIME_LED_TRANSITION);
    }
  }
  GPIO_Set_On_Output(PRT_D, PIN_16);
}

void WINDOW_State_Anti_Pinch(uint8_t *ptrWindowPosition, uint8_t *ptrWindowMovement, uint8_t *ptrAntiPinchFlag)
{
  if((*ptrAntiPinchFlag == TRUE) && (*ptrWindowPosition != MAX_POSITION))
  {
    GPIO_Set_Off_Output(PRT_D, PIN_16);
    while((*ptrWindowPosition > MIN_POSITION))
    {
      WINDOW_Move_Down(ptrWindowPosition);
      TIMER_Delay_Milliseconds(TIME_LED_TRANSITION);
    }
    GPIO_Set_On_Output(PRT_D, PIN_16);
    *ptrAntiPinchFlag = FALSE;
    *ptrWindowMovement = WAIT_TIMER;
  }
  else
  {
    *ptrWindowMovement = DO_NOTHING;
  }
}

void WINDOW_Move_Up(uint8_t *ptrWindowPosition)
{
	uint8_t portChar;
	uint8_t portPin;
	if (*ptrWindowPosition < MAX_POSITION)
	{
		*ptrWindowPosition = *ptrWindowPosition + (uint8_t)1;

		portChar = WINDOW_Get_Port_Char(ptrWindowPosition);
		portPin = WINDOW_Get_Port_Pin(ptrWindowPosition);
		GPIO_Set_On_Output(portChar, portPin);
	}
}

void WINDOW_Move_Down(uint8_t *ptrWindowPosition)
{
	uint8_t portChar;
	uint8_t portPin;
	if (*ptrWindowPosition > MIN_POSITION)
	{
		portChar = WINDOW_Get_Port_Char(ptrWindowPosition);
		portPin = WINDOW_Get_Port_Pin(ptrWindowPosition);
		GPIO_Set_Off_Output(portChar, portPin);

		*ptrWindowPosition = *ptrWindowPosition - (uint8_t)1;
	}
}

uint8_t WINDOW_Get_Port_Char(uint8_t *ptrWindowPosition)
{
	uint8_t portCharacter = 'Z';
	if (*ptrWindowPosition <= MAX_POSITION && *ptrWindowPosition >= MIN_POSITION)
	{
		switch(*ptrWindowPosition)
		{
			case 1:
				portCharacter = PRT_E;
				break;
			case 2:
				portCharacter = PRT_E;
				break;
			case 3:
				portCharacter = PRT_A;
				break;
			case 4:
				portCharacter = PRT_A;
				break;
			case 5:
				portCharacter = PRT_D;
				break;
			case 6:
				portCharacter = PRT_D;
				break;
			case 7:
				portCharacter = PRT_D;
				break;
			case 8:
				portCharacter = PRT_D;
				break;
			case 9:
				portCharacter = PRT_D;
				break;
			case 10:
				portCharacter = PRT_E;
				break;
			default:
				break;
		}
	}

	return portCharacter;

}

uint8_t WINDOW_Get_Port_Pin(uint8_t *ptrWindowPosition)
{	uint8_t portPin = 12;
	if (*ptrWindowPosition <= MAX_POSITION && *ptrWindowPosition >= MIN_POSITION)
	{
		switch(*ptrWindowPosition)
		{
			case 1:
				portPin = PIN_5;
				break;
			case 2:
				portPin = PIN_4;
				break;
			case 3:
				portPin = PIN_11;
				break;
			case 4:
				portPin = PIN_17;
				break;
			case 5:
				portPin = PIN_10;
				break;
			case 6:
				portPin = PIN_11;
				break;
			case 7:
				portPin = PIN_12;
				break;
			case 8:
				portPin = PIN_5;
				break;
			case 9:
				portPin = PIN_3;
				break;
			case 10:
				portPin = PIN_3;
				break;
			default:
				break;
		}
	}
	return portPin;
}

